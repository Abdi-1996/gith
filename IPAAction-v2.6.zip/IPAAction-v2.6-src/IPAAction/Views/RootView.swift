import SwiftUI

struct RootView: View {
    @EnvironmentObject private var model: AppModel
    @State private var showSettings = false
    @State private var showCreateRepository = false
    @State private var importSheet: ImportSheet?
    @State private var repoToRename: GitHubRepository?
    @State private var repoToDelete: GitHubRepository?
    @State private var isDeletingRepository = false

    enum ImportSheet: String, Identifiable {
        case project
        case workflow
        var id: String { rawValue }
    }

    var body: some View {
        NavigationStack {
            Group {
                if model.token.isEmpty {
                    ContentUnavailableView("Connect GitHub", systemImage: "chevron.left.forwardslash.chevron.right", description: Text("Add a GitHub token in Settings to manage repositories, files and IPA builds from your iPhone."))
                } else if model.isLoading && model.repositories.isEmpty {
                    ProgressView("Loading repositories…")
                } else if model.repositories.isEmpty {
                    ContentUnavailableView {
                        Label("No repositories", systemImage: "shippingbox")
                    } description: {
                        Text("Create a repository or check token access.")
                    } actions: {
                        Button("Create Repository") { showCreateRepository = true }
                            .buttonStyle(.borderedProminent)
                    }
                } else {
                    List {
                        ForEach(model.repositories) { repo in
                            NavigationLink(value: repo) {
                                HStack(spacing: 12) {
                                    Image(systemName: repo.private ? "lock.fill" : "globe")
                                        .frame(width: 28, height: 28)
                                    VStack(alignment: .leading, spacing: 3) {
                                        Text(repo.name).font(.headline)
                                        Text(repo.full_name).font(.caption).foregroundStyle(.secondary)
                                    }
                                    Spacer()
                                    Text(repo.default_branch).font(.caption2).foregroundStyle(.secondary)
                                }
                                .padding(.vertical, 3)
                            }
                            .swipeActions(edge: .trailing, allowsFullSwipe: false) {
                                Button(role: .destructive) {
                                    repoToDelete = repo
                                } label: {
                                    Label("Delete", systemImage: "trash")
                                }
                                Button {
                                    repoToRename = repo
                                } label: {
                                    Label("Rename", systemImage: "pencil")
                                }
                                .tint(.blue)
                            }
                            .contextMenu {
                                Button { repoToRename = repo } label: {
                                    Label("Rename Repository", systemImage: "pencil")
                                }
                                Button(role: .destructive) { repoToDelete = repo } label: {
                                    Label("Delete Repository", systemImage: "trash")
                                }
                            }
                        }
                    }
                    .refreshable { await model.loadRepositories() }
                }
            }
            .navigationTitle("IPA Action")
            .navigationDestination(for: GitHubRepository.self) { repo in
                RepositoryView(repository: repo)
            }
            .toolbar {
                ToolbarItem(placement: .topBarLeading) {
                    Menu {
                        Button {
                            showCreateRepository = true
                        } label: {
                            Label("New Repository", systemImage: "shippingbox.and.arrow.backward")
                        }
                        Divider()
                        Button {
                            importSheet = .project
                        } label: {
                            Label("Import Project ZIP", systemImage: "doc.zipper")
                        }
                        Button {
                            importSheet = .workflow
                        } label: {
                            Label("Import Workflow", systemImage: "doc.badge.gearshape")
                        }
                    } label: {
                        Image(systemName: "plus.circle.fill")
                    }
                    .disabled(model.token.isEmpty)
                }

                ToolbarItem(placement: .topBarTrailing) {
                    Button { showSettings = true } label: { Image(systemName: "gearshape.fill") }
                }
            }
            .sheet(isPresented: $showSettings) { SettingsView() }
            .sheet(isPresented: $showCreateRepository) { CreateRepositoryView() }
            .sheet(item: $repoToRename) { repo in RenameRepositoryView(repository: repo) }
            .sheet(item: $importSheet) { sheet in
                switch sheet {
                case .project: ProjectImportView()
                case .workflow: WorkflowImportView()
                }
            }
            .alert("Delete repository?", isPresented: Binding(
                get: { repoToDelete != nil },
                set: { if !$0 { repoToDelete = nil } }
            )) {
                Button("Cancel", role: .cancel) { repoToDelete = nil }
                Button("Delete permanently", role: .destructive) {
                    guard let repo = repoToDelete else { return }
                    repoToDelete = nil
                    Task { await deleteRepository(repo) }
                }
            } message: {
                if let repo = repoToDelete {
                    Text("Delete \(repo.full_name) and all of its files? This is permanent.")
                }
            }
            .alert("Error", isPresented: Binding(get: { model.errorMessage != nil }, set: { if !$0 { model.errorMessage = nil } })) {
                Button("OK", role: .cancel) { model.errorMessage = nil }
            } message: { Text(model.errorMessage ?? "Unknown error") }
        }
    }

    private func deleteRepository(_ repo: GitHubRepository) async {
        isDeletingRepository = true
        defer { isDeletingRepository = false }
        do {
            try await model.deleteRepository(repo)
        } catch {
            model.errorMessage = error.localizedDescription
        }
    }
}
