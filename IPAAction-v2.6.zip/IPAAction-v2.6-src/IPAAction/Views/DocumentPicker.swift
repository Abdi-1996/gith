import SwiftUI
import UniformTypeIdentifiers
import UIKit

struct ImportedLocalFile: Identifiable, Hashable {
    let id = UUID()
    let url: URL
    let originalName: String
    let size: Int64
}

enum DocumentImportError: LocalizedError {
    case noFiles
    case copyFailed(String)

    var errorDescription: String? {
        switch self {
        case .noFiles:
            return "No files were selected."
        case let .copyFailed(message):
            return "Could not copy the selected file into IPA Action: \(message)"
        }
    }
}

struct AnyDocumentPicker: UIViewControllerRepresentable {
    let allowsMultipleSelection: Bool
    let onPick: ([ImportedLocalFile]) -> Void
    let onError: (Error) -> Void
    let onCancel: () -> Void

    init(
        allowsMultipleSelection: Bool = true,
        onPick: @escaping ([ImportedLocalFile]) -> Void,
        onError: @escaping (Error) -> Void,
        onCancel: @escaping () -> Void
    ) {
        self.allowsMultipleSelection = allowsMultipleSelection
        self.onPick = onPick
        self.onError = onError
        self.onCancel = onCancel
    }

    func makeCoordinator() -> Coordinator { Coordinator(parent: self) }

    func makeUIViewController(context: Context) -> UIDocumentPickerViewController {
        let picker = UIDocumentPickerViewController(forOpeningContentTypes: [.item], asCopy: true)
        picker.allowsMultipleSelection = allowsMultipleSelection
        picker.shouldShowFileExtensions = true
        picker.delegate = context.coordinator
        return picker
    }

    func updateUIViewController(_ uiViewController: UIDocumentPickerViewController, context: Context) {}

    final class Coordinator: NSObject, UIDocumentPickerDelegate {
        let parent: AnyDocumentPicker
        init(parent: AnyDocumentPicker) { self.parent = parent }

        func documentPicker(_ controller: UIDocumentPickerViewController, didPickDocumentsAt urls: [URL]) {
            guard !urls.isEmpty else {
                parent.onError(DocumentImportError.noFiles)
                return
            }

            do {
                let imported = try copyIntoApp(urls)
                parent.onPick(imported)
            } catch {
                parent.onError(error)
            }
        }

        func documentPickerWasCancelled(_ controller: UIDocumentPickerViewController) {
            parent.onCancel()
        }

        private func copyIntoApp(_ urls: [URL]) throws -> [ImportedLocalFile] {
            let fm = FileManager.default
            let root = fm.temporaryDirectory
                .appendingPathComponent("IPAActionImports", isDirectory: true)
                .appendingPathComponent(UUID().uuidString, isDirectory: true)
            try fm.createDirectory(at: root, withIntermediateDirectories: true)

            var result: [ImportedLocalFile] = []
            var usedNames = Set<String>()

            for sourceURL in urls {
                let scoped = sourceURL.startAccessingSecurityScopedResource()
                defer { if scoped { sourceURL.stopAccessingSecurityScopedResource() } }

                let originalName = sourceURL.lastPathComponent.isEmpty ? "ImportedFile" : sourceURL.lastPathComponent
                let safeName = uniqueName(originalName, used: &usedNames)
                let destination = root.appendingPathComponent(safeName, isDirectory: false)

                do {
                    if fm.fileExists(atPath: destination.path) {
                        try fm.removeItem(at: destination)
                    }
                    try fm.copyItem(at: sourceURL, to: destination)
                    let values = try destination.resourceValues(forKeys: [.fileSizeKey, .isRegularFileKey])
                    guard values.isRegularFile == true else {
                        throw DocumentImportError.copyFailed("\(originalName) is not a regular file")
                    }
                    result.append(ImportedLocalFile(
                        url: destination,
                        originalName: originalName,
                        size: Int64(values.fileSize ?? 0)
                    ))
                } catch {
                    throw DocumentImportError.copyFailed("\(originalName): \(error.localizedDescription)")
                }
            }

            return result
        }

        private func uniqueName(_ name: String, used: inout Set<String>) -> String {
            if !used.contains(name) {
                used.insert(name)
                return name
            }

            let ns = name as NSString
            let base = ns.deletingPathExtension
            let ext = ns.pathExtension
            var index = 2
            while true {
                let candidate = ext.isEmpty ? "\(base)-\(index)" : "\(base)-\(index).\(ext)"
                if !used.contains(candidate) {
                    used.insert(candidate)
                    return candidate
                }
                index += 1
            }
        }
    }
}
