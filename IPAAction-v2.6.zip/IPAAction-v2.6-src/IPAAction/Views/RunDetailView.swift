import SwiftUI
import UIKit

struct RunDetailView: View {
    let repository: GitHubRepository
    @State var run: GitHubRun
    @EnvironmentObject private var model: AppModel
    @Environment(\.openURL) private var openURL
    @State private var artifacts: [GitHubArtifact] = []
    @State private var ipaURL: URL?
    @State private var isBusy = false
    @State private var installResult: String?
    @State private var showShare = false

    private var owner: String { repository.owner.login }

    var body: some View {
        List {
            Section("Run") {
                LabeledContent("Run", value: "#\(run.run_number)")
                LabeledContent("Status", value: BuildStateLabel.text(status: run.status, conclusion: run.conclusion))
                if let branch = run.head_branch { LabeledContent("Branch", value: branch) }
                Button("Open on GitHub") { if let url = URL(string: run.html_url) { openURL(url) } }
                if run.status != "completed" {
                    Button("Cancel run", role: .destructive) { Task { await cancel() } }
                }
            }

            Section("Artifacts") {
                if artifacts.isEmpty {
                    Text(run.status == "completed" ? "No artifacts found." : "Artifacts will appear after the workflow uploads them.")
                        .foregroundStyle(.secondary)
                }
                ForEach(artifacts) { artifact in
                    Button {
                        Task { await download(artifact) }
                    } label: {
                        HStack {
                            VStack(alignment: .leading) {
                                Text(artifact.name)
                                Text(ByteCountFormatter.string(fromByteCount: Int64(artifact.size_in_bytes), countStyle: .file)).font(.caption).foregroundStyle(.secondary)
                            }
                            Spacer()
                            Image(systemName: "arrow.down.circle")
                        }
                    }.disabled(artifact.expired || isBusy)
                }
            }

            if let ipaURL {
                Section("IPA") {
                    LabeledContent("File", value: ipaURL.lastPathComponent)
                    Button("Share / Save IPA") { showShare = true }
                    Button("Install with Sideloader") { Task { await install() } }
                        .disabled(model.sideloaderURL.isEmpty || isBusy)
                }
            }

            if let installResult {
                Section("Sideloader response") { Text(installResult).font(.caption.monospaced()) }
            }
        }
        .navigationTitle("Build #\(run.run_number)")
        .overlay { if isBusy { ProgressView().controlSize(.large) } }
        .task { await loadArtifacts() }
        .refreshable { await loadArtifacts() }
        .sheet(isPresented: $showShare) {
            if let ipaURL { ActivityView(items: [ipaURL]) }
        }
    }

    private func loadArtifacts() async {
        do { artifacts = try await model.githubAPI().artifacts(owner: owner, repo: repository.name, runID: run.id) }
        catch { model.errorMessage = error.localizedDescription }
    }

    private func download(_ artifact: GitHubArtifact) async {
        isBusy = true
        defer { isBusy = false }
        do { ipaURL = try await model.githubAPI().downloadIPA(owner: owner, repo: repository.name, artifact: artifact) }
        catch { model.errorMessage = error.localizedDescription }
    }

    private func cancel() async {
        isBusy = true
        defer { isBusy = false }
        do {
            try await model.githubAPI().cancel(owner: owner, repo: repository.name, runID: run.id)
            model.errorMessage = nil
        } catch { model.errorMessage = error.localizedDescription }
    }

    private func install() async {
        guard let ipaURL else { return }
        isBusy = true
        defer { isBusy = false }
        do {
            installResult = try await SideloaderClient().install(ipaURL: ipaURL, baseURL: model.sideloaderURL, apiKey: model.sideloaderAPIKey)
        } catch { model.errorMessage = error.localizedDescription }
    }
}

struct ActivityView: UIViewControllerRepresentable {
    let items: [Any]
    func makeUIViewController(context: Context) -> UIActivityViewController { UIActivityViewController(activityItems: items, applicationActivities: nil) }
    func updateUIViewController(_ uiViewController: UIActivityViewController, context: Context) {}
}
