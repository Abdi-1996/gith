import SwiftUI

struct RepositoryView: View {
    let repository: GitHubRepository
    @EnvironmentObject private var model: AppModel
    @State private var workflows: [GitHubWorkflow] = []
    @State private var branches: [GitHubBranch] = []
    @State private var selectedWorkflow: GitHubWorkflow?
    @State private var selectedBranch = ""
    @State private var runs: [GitHubRun] = []
    @State private var isBusy = false
    @State private var lastDispatchAt: Date?

    private var owner: String { repository.owner.login }

    var body: some View {
        List {
            Section("Repository") {
                NavigationLink {
                    RepositoryFilesView(repository: repository)
                } label: {
                    Label("Files", systemImage: "folder.fill")
                }

                NavigationLink {
                    RepositorySettingsView(repository: repository)
                } label: {
                    Label("Repository Settings", systemImage: "gearshape")
                }
            }

            Section("Build") {
                Picker("Workflow", selection: $selectedWorkflow) {
                    Text("Select workflow").tag(GitHubWorkflow?.none)
                    ForEach(workflows) { Text($0.name).tag(Optional($0)) }
                }
                Picker("Branch", selection: $selectedBranch) {
                    ForEach(branches) { Text($0.name).tag($0.name) }
                }
                Button {
                    Task { await startBuild() }
                } label: {
                    HStack {
                        Image(systemName: "hammer.fill")
                        Text("Build IPA").fontWeight(.semibold)
                        Spacer()
                        if isBusy { ProgressView() }
                    }
                }
                .disabled(selectedWorkflow == nil || selectedBranch.isEmpty || isBusy)
            }

            Section("Recent runs") {
                if runs.isEmpty { Text("No runs yet").foregroundStyle(.secondary) }
                ForEach(runs) { run in
                    NavigationLink {
                        RunDetailView(repository: repository, run: run)
                    } label: {
                        VStack(alignment: .leading, spacing: 5) {
                            HStack {
                                Text("#\(run.run_number) \(run.name ?? "Workflow")").font(.headline)
                                Spacer()
                                StatusBadge(run: run)
                            }
                            Text(run.head_branch ?? selectedBranch).font(.caption).foregroundStyle(.secondary)
                        }.padding(.vertical, 3)
                    }
                }
            }
        }
        .navigationTitle(repository.name)
        .task { await load() }
        .refreshable { await refreshRuns() }
    }

    private func load() async {
        isBusy = true
        defer { isBusy = false }
        do {
            async let ws = model.githubAPI().workflows(owner: owner, repo: repository.name)
            async let bs = model.githubAPI().branches(owner: owner, repo: repository.name)
            workflows = try await ws.filter { $0.state == "active" }
            branches = try await bs
            selectedWorkflow = workflows.first
            selectedBranch = branches.first(where: { $0.name == repository.default_branch })?.name ?? branches.first?.name ?? repository.default_branch
            await refreshRuns()
        } catch { model.errorMessage = error.localizedDescription }
    }

    private func refreshRuns() async {
        guard let selectedWorkflow else { return }
        do { runs = try await model.githubAPI().runs(owner: owner, repo: repository.name, workflowID: selectedWorkflow.id, branch: selectedBranch) }
        catch { model.errorMessage = error.localizedDescription }
    }

    private func startBuild() async {
        guard let workflow = selectedWorkflow else { return }
        isBusy = true
        defer { isBusy = false }
        do {
            try await model.githubAPI().dispatch(owner: owner, repo: repository.name, workflowID: workflow.id, ref: selectedBranch)
            lastDispatchAt = Date()
            try? await Task.sleep(for: .seconds(2))
            runs = try await model.githubAPI().runs(owner: owner, repo: repository.name, workflowID: workflow.id, branch: selectedBranch)
        } catch { model.errorMessage = error.localizedDescription }
    }
}

struct StatusBadge: View {
    let run: GitHubRun
    var body: some View {
        Text(BuildStateLabel.text(status: run.status, conclusion: run.conclusion))
            .font(.caption2.weight(.semibold))
            .padding(.horizontal, 8).padding(.vertical, 4)
            .background(.thinMaterial, in: Capsule())
    }
}
