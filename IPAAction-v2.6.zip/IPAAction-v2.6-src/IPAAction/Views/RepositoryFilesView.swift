import SwiftUI
import Foundation

struct RepositoryFilesView: View {
    let repository: GitHubRepository
    @EnvironmentObject private var model: AppModel

    @State private var branches: [GitHubBranch] = []
    @State private var selectedBranch = ""
    @State private var isLoading = true

    var body: some View {
        VStack(spacing: 0) {
            if !branches.isEmpty {
                HStack {
                    Image(systemName: "arrow.triangle.branch")
                        .foregroundStyle(.secondary)
                    Picker("Branch", selection: $selectedBranch) {
                        ForEach(branches) { branch in
                            Text(branch.name).tag(branch.name)
                        }
                    }
                    .pickerStyle(.menu)
                    Spacer()
                }
                .padding(.horizontal)
                .frame(minHeight: 48)
                Divider()
            }

            if isLoading {
                Spacer()
                ProgressView("Loading files…")
                Spacer()
            } else if selectedBranch.isEmpty {
                ContentUnavailableView("No branch", systemImage: "arrow.triangle.branch", description: Text("This repository does not have a branch yet."))
            } else {
                RepositoryFolderView(repository: repository, branch: selectedBranch, path: "")
                    .id(selectedBranch)
            }
        }
        .navigationTitle("Files")
        .navigationBarTitleDisplayMode(.inline)
        .task { await loadBranches() }
    }

    private func loadBranches() async {
        isLoading = true
        defer { isLoading = false }
        do {
            branches = try await model.githubAPI().branches(owner: repository.owner.login, repo: repository.name)
            selectedBranch = branches.first(where: { $0.name == repository.default_branch })?.name
                ?? branches.first?.name
                ?? ""
        } catch {
            model.errorMessage = error.localizedDescription
        }
    }
}

struct RepositoryFolderView: View {
    let repository: GitHubRepository
    let branch: String
    let path: String

    @EnvironmentObject private var model: AppModel
    @State private var items: [GitHubContentItem] = []
    @State private var isLoading = true
    @State private var isWorking = false
    @State private var showImporter = false
    @State private var showNewFile = false
    @State private var showNewFolder = false
    @State private var itemToDelete: GitHubContentItem?
    @State private var itemToMove: GitHubContentItem?
    @State private var importProgressText: String?
    @State private var importSuccessText: String?

    private var owner: String { repository.owner.login }
    private var title: String { path.isEmpty ? repository.name : (path as NSString).lastPathComponent }

    var body: some View {
        Group {
            if isLoading {
                ProgressView("Loading…")
            } else if items.isEmpty {
                ContentUnavailableView("Empty folder", systemImage: "folder", description: Text("Create a file, folder, or import a file from your iPhone."))
            } else {
                List(items) { item in
                    row(item)
                        .swipeActions(edge: .trailing, allowsFullSwipe: false) {
                            Button(role: .destructive) {
                                itemToDelete = item
                            } label: {
                                Label("Delete", systemImage: "trash")
                            }
                            Button {
                                itemToMove = item
                            } label: {
                                Label("Move", systemImage: "arrow.right.square")
                            }
                            .tint(.blue)
                        }
                        .contextMenu {
                            Button {
                                itemToMove = item
                            } label: {
                                Label(item.isDirectory ? "Rename / Move Folder" : "Rename / Move File", systemImage: "pencil")
                            }
                            Button(role: .destructive) {
                                itemToDelete = item
                            } label: {
                                Label("Delete", systemImage: "trash")
                            }
                        }
                }
                .listStyle(.plain)
            }
        }
        .navigationTitle(title)
        .navigationBarTitleDisplayMode(.inline)
        .toolbar {
            ToolbarItem(placement: .topBarTrailing) {
                Menu {
                    Button { showNewFile = true } label: {
                        Label("New Text File", systemImage: "doc.badge.plus")
                    }
                    Button { showNewFolder = true } label: {
                        Label("New Folder", systemImage: "folder.badge.plus")
                    }
                    Button { showImporter = true } label: {
                        Label("Import File", systemImage: "square.and.arrow.down")
                    }
                } label: {
                    Image(systemName: "plus.circle.fill")
                }
                .disabled(isWorking)
            }
        }
        .overlay {
            if isWorking {
                ZStack {
                    Color.black.opacity(0.10).ignoresSafeArea()
                    VStack(spacing: 12) {
                        ProgressView().controlSize(.large)
                        Text(importProgressText ?? "Working…")
                            .font(.subheadline.weight(.semibold))
                            .multilineTextAlignment(.center)
                    }
                    .padding(22)
                    .background(.regularMaterial, in: RoundedRectangle(cornerRadius: 18))
                }
            }
        }
        .task { await load() }
        .refreshable { await load() }
        .sheet(isPresented: $showImporter) {
            AnyDocumentPicker(
                allowsMultipleSelection: true,
                onPick: { files in
                    showImporter = false
                    Task { await importFiles(files) }
                },
                onError: { error in
                    showImporter = false
                    model.errorMessage = error.localizedDescription
                },
                onCancel: { showImporter = false }
            )
            .ignoresSafeArea()
        }
        .sheet(isPresented: $showNewFile) {
            NewRepositoryTextFileView(repository: repository, branch: branch, folderPath: path) {
                Task { await load() }
            }
        }
        .sheet(isPresented: $showNewFolder) {
            NewRepositoryFolderView(repository: repository, branch: branch, parentPath: path) {
                Task { await load() }
            }
        }
        .sheet(item: $itemToMove) { item in
            MoveRepositoryItemView(repository: repository, branch: branch, item: item) {
                Task { await load() }
            }
        }
        .alert("Import complete", isPresented: Binding(
            get: { importSuccessText != nil },
            set: { if !$0 { importSuccessText = nil } }
        )) {
            Button("OK", role: .cancel) { importSuccessText = nil }
        } message: {
            Text(importSuccessText ?? "Files uploaded.")
        }
        .alert("Delete item?", isPresented: Binding(
            get: { itemToDelete != nil },
            set: { if !$0 { itemToDelete = nil } }
        )) {
            Button("Cancel", role: .cancel) { itemToDelete = nil }
            Button("Delete", role: .destructive) {
                if let item = itemToDelete {
                    itemToDelete = nil
                    Task { await delete(item) }
                }
            }
        } message: {
            if let item = itemToDelete {
                Text(item.isDirectory ? "Delete folder “\(item.name)” and all files inside it?" : "Delete “\(item.name)” from branch \(branch)?")
            }
        }
    }

    @ViewBuilder
    private func row(_ item: GitHubContentItem) -> some View {
        if item.isDirectory {
            NavigationLink {
                RepositoryFolderView(repository: repository, branch: branch, path: item.path)
            } label: {
                FileRow(item: item)
            }
        } else {
            NavigationLink {
                RepositoryFileView(repository: repository, branch: branch, item: item)
            } label: {
                FileRow(item: item)
            }
        }
    }

    private func load() async {
        isLoading = true
        defer { isLoading = false }
        do {
            items = try await model.githubAPI().contents(owner: owner, repo: repository.name, path: path, branch: branch)
        } catch {
            model.errorMessage = error.localizedDescription
        }
    }

    private func joinedPath(_ name: String) -> String {
        let clean = name.trimmingCharacters(in: CharacterSet(charactersIn: "/"))
        return path.isEmpty ? clean : "\(path)/\(clean)"
    }

    private func importFiles(_ files: [ImportedLocalFile]) async {
        guard !files.isEmpty else { return }
        isWorking = true
        defer {
            isWorking = false
            importProgressText = nil
        }

        var uploaded: [String] = []
        var failures: [String] = []

        for (index, file) in files.enumerated() {
            importProgressText = "Uploading \(index + 1) of \(files.count)\n\(file.originalName)"
            do {
                let data = try Data(contentsOf: file.url, options: .mappedIfSafe)
                let remotePath = joinedPath(file.originalName)
                _ = try await model.githubAPI().uploadFile(
                    owner: owner,
                    repo: repository.name,
                    path: remotePath,
                    data: data,
                    branch: branch,
                    message: "Import \(file.originalName) from IPA Action"
                )
                uploaded.append(file.originalName)
            } catch {
                failures.append("\(file.originalName): \(error.localizedDescription)")
            }
        }

        await load()

        if failures.isEmpty {
            importSuccessText = uploaded.count == 1
                ? "\(uploaded[0]) was uploaded to branch \(branch)."
                : "\(uploaded.count) files were uploaded to branch \(branch)."
        } else if uploaded.isEmpty {
            model.errorMessage = failures.joined(separator: "\n\n")
        } else {
            model.errorMessage = "Uploaded \(uploaded.count) file(s), but some failed:\n\n" + failures.joined(separator: "\n\n")
        }
    }

    private func delete(_ item: GitHubContentItem) async {
        isWorking = true
        defer { isWorking = false }
        do {
            if item.isDirectory {
                try await model.githubAPI().deleteDirectory(owner: owner, repo: repository.name, path: item.path, branch: branch)
            } else {
                try await model.githubAPI().deleteFile(owner: owner, repo: repository.name, path: item.path, sha: item.sha, branch: branch)
            }
            await load()
        } catch {
            model.errorMessage = error.localizedDescription
        }
    }
}

struct FileRow: View {
    let item: GitHubContentItem

    var body: some View {
        HStack(spacing: 12) {
            Image(systemName: item.isDirectory ? "folder.fill" : iconForFile(item.name))
                .foregroundStyle(item.isDirectory ? Color.accentColor : Color.secondary)
                .frame(width: 28)
            VStack(alignment: .leading, spacing: 3) {
                Text(item.name)
                    .lineLimit(1)
                if !item.isDirectory, let size = item.size {
                    Text(ByteCountFormatter.string(fromByteCount: Int64(size), countStyle: .file))
                        .font(.caption2)
                        .foregroundStyle(.secondary)
                }
            }
        }
        .padding(.vertical, 3)
    }

    private func iconForFile(_ name: String) -> String {
        let ext = (name as NSString).pathExtension.lowercased()
        switch ext {
        case "swift": return "swift"
        case "json", "yml", "yaml", "xml", "md", "txt", "html", "css", "js", "ts": return "doc.text"
        case "zip": return "doc.zipper"
        case "png", "jpg", "jpeg", "heic", "webp": return "photo"
        case "mp4", "mov": return "film"
        default: return "doc"
        }
    }
}

struct RepositoryFileView: View {
    let repository: GitHubRepository
    let branch: String
    let item: GitHubContentItem

    @EnvironmentObject private var model: AppModel
    @Environment(\.dismiss) private var dismiss
    @State private var text = ""
    @State private var isText = false
    @State private var isLoading = true
    @State private var isEditing = false
    @State private var isWorking = false
    @State private var shareURL: URL?
    @State private var showShare = false
    @State private var showMove = false
    @State private var showDelete = false

    private var owner: String { repository.owner.login }

    var body: some View {
        Group {
            if isLoading {
                ProgressView("Loading file…")
            } else if isText {
                TextEditor(text: $text)
                    .font(.system(.body, design: .monospaced))
                    .padding(.horizontal, 8)
                    .disabled(!isEditing)
                    .overlay(alignment: .topTrailing) {
                        if !isEditing {
                            Text("READ ONLY")
                                .font(.caption2.bold())
                                .padding(6)
                                .background(.thinMaterial, in: Capsule())
                                .padding()
                        }
                    }
            } else {
                ContentUnavailableView {
                    Label("Binary file", systemImage: "doc")
                } description: {
                    Text("This file cannot be edited as UTF-8 text, but you can share, rename, move, replace or delete it.")
                } actions: {
                    Button("Share / Save") { Task { await prepareShare() } }
                        .buttonStyle(.borderedProminent)
                }
            }
        }
        .navigationTitle(item.name)
        .navigationBarTitleDisplayMode(.inline)
        .toolbar {
            ToolbarItem(placement: .topBarTrailing) {
                if isText {
                    Button(isEditing ? "Save" : "Edit") {
                        if isEditing { Task { await saveText() } }
                        else { isEditing = true }
                    }
                    .disabled(isWorking)
                }
            }
            ToolbarItem(placement: .topBarTrailing) {
                Menu {
                    Button { Task { await prepareShare() } } label: {
                        Label("Share / Save", systemImage: "square.and.arrow.up")
                    }
                    Button { showMove = true } label: {
                        Label("Rename / Move", systemImage: "pencil")
                    }
                    Button(role: .destructive) { showDelete = true } label: {
                        Label("Delete", systemImage: "trash")
                    }
                } label: {
                    Image(systemName: "ellipsis.circle")
                }
            }
        }
        .overlay { if isWorking { ProgressView().controlSize(.large) } }
        .task { await load() }
        .sheet(isPresented: $showShare) {
            if let shareURL { ActivityView(items: [shareURL]) }
        }
        .sheet(isPresented: $showMove) {
            MoveRepositoryItemView(repository: repository, branch: branch, item: item) {
                dismiss()
            }
        }
        .alert("Delete file?", isPresented: $showDelete) {
            Button("Cancel", role: .cancel) {}
            Button("Delete", role: .destructive) { Task { await deleteFile() } }
        } message: {
            Text("Delete \(item.path) from branch \(branch)?")
        }
    }

    private func load() async {
        isLoading = true
        defer { isLoading = false }
        do {
            let data = try await model.githubAPI().rawFileData(owner: owner, repo: repository.name, path: item.path, branch: branch)
            if data.count <= 2 * 1024 * 1024, let decoded = String(data: data, encoding: .utf8) {
                text = decoded
                isText = true
            } else {
                isText = false
            }
        } catch {
            model.errorMessage = error.localizedDescription
        }
    }

    private func saveText() async {
        isWorking = true
        defer { isWorking = false }
        do {
            guard let data = text.data(using: .utf8) else { throw GitHubAPIError.invalidTextFile }
            _ = try await model.githubAPI().uploadFile(
                owner: owner,
                repo: repository.name,
                path: item.path,
                data: data,
                branch: branch,
                message: "Edit \(item.path) from IPA Action"
            )
            isEditing = false
        } catch {
            model.errorMessage = error.localizedDescription
        }
    }

    private func prepareShare() async {
        isWorking = true
        defer { isWorking = false }
        do {
            let data = try await model.githubAPI().rawFileData(owner: owner, repo: repository.name, path: item.path, branch: branch)
            let dir = FileManager.default.temporaryDirectory.appendingPathComponent("IPAActionShare", isDirectory: true)
            try FileManager.default.createDirectory(at: dir, withIntermediateDirectories: true)
            let url = dir.appendingPathComponent(item.name)
            try? FileManager.default.removeItem(at: url)
            try data.write(to: url, options: .atomic)
            shareURL = url
            showShare = true
        } catch {
            model.errorMessage = error.localizedDescription
        }
    }

    private func deleteFile() async {
        isWorking = true
        defer { isWorking = false }
        do {
            try await model.githubAPI().deleteFile(owner: owner, repo: repository.name, path: item.path, sha: item.sha, branch: branch)
            dismiss()
        } catch {
            model.errorMessage = error.localizedDescription
        }
    }
}

struct NewRepositoryTextFileView: View {
    @Environment(\.dismiss) private var dismiss
    @EnvironmentObject private var model: AppModel
    let repository: GitHubRepository
    let branch: String
    let folderPath: String
    let onCreated: () -> Void

    @State private var name = "new-file.txt"
    @State private var content = ""
    @State private var isWorking = false

    var body: some View {
        NavigationStack {
            VStack(spacing: 0) {
                TextField("File name", text: $name)
                    .textInputAutocapitalization(.never)
                    .autocorrectionDisabled()
                    .textFieldStyle(.roundedBorder)
                    .padding()
                Divider()
                TextEditor(text: $content)
                    .font(.system(.body, design: .monospaced))
                    .padding(8)
            }
            .navigationTitle("New File")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .cancellationAction) { Button("Cancel") { dismiss() } }
                ToolbarItem(placement: .confirmationAction) {
                    Button {
                        Task { await create() }
                    } label: {
                        if isWorking { ProgressView() } else { Text("Create").fontWeight(.semibold) }
                    }
                    .disabled(name.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty || isWorking)
                }
            }
        }
    }

    private func create() async {
        isWorking = true
        defer { isWorking = false }
        do {
            let clean = name.trimmingCharacters(in: CharacterSet(charactersIn: "/").union(.whitespacesAndNewlines))
            let remote = folderPath.isEmpty ? clean : "\(folderPath)/\(clean)"
            try await model.githubAPI().createTextFile(owner: repository.owner.login, repo: repository.name, path: remote, text: content, branch: branch)
            onCreated()
            dismiss()
        } catch {
            model.errorMessage = error.localizedDescription
        }
    }
}

struct NewRepositoryFolderView: View {
    @Environment(\.dismiss) private var dismiss
    @EnvironmentObject private var model: AppModel
    let repository: GitHubRepository
    let branch: String
    let parentPath: String
    let onCreated: () -> Void

    @State private var name = "NewFolder"
    @State private var isWorking = false

    var body: some View {
        NavigationStack {
            Form {
                TextField("Folder name", text: $name)
                    .textInputAutocapitalization(.never)
                    .autocorrectionDisabled()
                Text("Git stores files, not empty folders. IPA Action creates a small .gitkeep file so the folder exists in GitHub.")
                    .font(.caption)
                    .foregroundStyle(.secondary)
            }
            .navigationTitle("New Folder")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .cancellationAction) { Button("Cancel") { dismiss() } }
                ToolbarItem(placement: .confirmationAction) {
                    Button {
                        Task { await create() }
                    } label: {
                        if isWorking { ProgressView() } else { Text("Create").fontWeight(.semibold) }
                    }
                    .disabled(name.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty || isWorking)
                }
            }
        }
    }

    private func create() async {
        isWorking = true
        defer { isWorking = false }
        do {
            let clean = name.trimmingCharacters(in: CharacterSet(charactersIn: "/").union(.whitespacesAndNewlines))
            let remote = parentPath.isEmpty ? clean : "\(parentPath)/\(clean)"
            try await model.githubAPI().createFolder(owner: repository.owner.login, repo: repository.name, path: remote, branch: branch)
            onCreated()
            dismiss()
        } catch {
            model.errorMessage = error.localizedDescription
        }
    }
}

struct MoveRepositoryItemView: View {
    @Environment(\.dismiss) private var dismiss
    @EnvironmentObject private var model: AppModel
    let repository: GitHubRepository
    let branch: String
    let item: GitHubContentItem
    let onMoved: () -> Void

    @State private var destinationPath: String
    @State private var isWorking = false

    init(repository: GitHubRepository, branch: String, item: GitHubContentItem, onMoved: @escaping () -> Void) {
        self.repository = repository
        self.branch = branch
        self.item = item
        self.onMoved = onMoved
        _destinationPath = State(initialValue: item.path)
    }

    var body: some View {
        NavigationStack {
            Form {
                Section(item.isDirectory ? "Folder path" : "File path") {
                    TextField("Destination path", text: $destinationPath)
                        .textInputAutocapitalization(.never)
                        .autocorrectionDisabled()
                }
                Section {
                    Text("Change just the last component to rename it, or change the full path to move it to another folder.")
                        .font(.caption)
                        .foregroundStyle(.secondary)
                }
            }
            .navigationTitle("Rename / Move")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .cancellationAction) { Button("Cancel") { dismiss() } }
                ToolbarItem(placement: .confirmationAction) {
                    Button {
                        Task { await move() }
                    } label: {
                        if isWorking { ProgressView() } else { Text("Move").fontWeight(.semibold) }
                    }
                    .disabled(destinationPath.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty || destinationPath == item.path || isWorking)
                }
            }
        }
    }

    private func move() async {
        isWorking = true
        defer { isWorking = false }
        do {
            if item.isDirectory {
                try await model.githubAPI().moveDirectory(
                    owner: repository.owner.login,
                    repo: repository.name,
                    sourcePath: item.path,
                    destinationPath: destinationPath,
                    branch: branch
                )
            } else {
                try await model.githubAPI().moveFile(
                    owner: repository.owner.login,
                    repo: repository.name,
                    source: item,
                    destinationPath: destinationPath,
                    branch: branch
                )
            }
            onMoved()
            dismiss()
        } catch {
            model.errorMessage = error.localizedDescription
        }
    }
}
