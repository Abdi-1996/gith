import Foundation
import ZIPFoundation

enum GitHubAPIError: LocalizedError {
    case missingToken
    case invalidResponse
    case http(Int, String)
    case ipaNotFound
    case fileTooLarge(Int64)
    case invalidFileName
    case invalidTextFile
    case invalidMove

    var errorDescription: String? {
        switch self {
        case .missingToken: return "GitHub token is missing."
        case .invalidResponse: return "GitHub returned an invalid response."
        case let .http(code, message): return "GitHub API error \(code): \(message)"
        case .ipaNotFound: return "The downloaded artifact does not contain an .ipa file."
        case let .fileTooLarge(bytes):
            return "The file is too large for direct GitHub upload (\(ByteCountFormatter.string(fromByteCount: bytes, countStyle: .file))). Keep direct uploads under 75 MB in IPA Action."
        case .invalidFileName: return "The file or repository name is invalid."
        case .invalidTextFile: return "This file cannot be edited as UTF-8 text."
        case .invalidMove: return "Source and destination paths must be different."
        }
    }
}

actor GitHubAPI {
    private let decoder = JSONDecoder()
    private let session: URLSession
    var token: String

    init(token: String, session: URLSession = .shared) {
        self.token = token
        self.session = session
    }

    func setToken(_ token: String) { self.token = token }

    private func request(_ path: String, method: String = "GET", body: Data? = nil, accept: String = "application/vnd.github+json") throws -> URLRequest {
        guard !token.isEmpty else { throw GitHubAPIError.missingToken }
        guard let url = URL(string: "https://api.github.com\(path)") else { throw GitHubAPIError.invalidResponse }
        var req = URLRequest(url: url)
        req.httpMethod = method
        req.httpBody = body
        req.setValue("Bearer \(token)", forHTTPHeaderField: "Authorization")
        req.setValue(accept, forHTTPHeaderField: "Accept")
        req.setValue("application/json", forHTTPHeaderField: "Content-Type")
        req.setValue("2026-03-10", forHTTPHeaderField: "X-GitHub-Api-Version")
        req.setValue("IPAAction-iOS", forHTTPHeaderField: "User-Agent")
        return req
    }

    private func response(_ req: URLRequest) async throws -> (Data, HTTPURLResponse) {
        let (data, response) = try await session.data(for: req)
        guard let http = response as? HTTPURLResponse else { throw GitHubAPIError.invalidResponse }
        return (data, http)
    }

    private func errorMessage(from data: Data) -> String {
        (try? JSONSerialization.jsonObject(with: data) as? [String: Any])?["message"] as? String
        ?? String(data: data, encoding: .utf8)
        ?? "Unknown error"
    }

    private func perform(_ req: URLRequest, allowEmpty: Bool = false) async throws -> Data {
        let (data, http) = try await response(req)
        guard (200..<300).contains(http.statusCode) else {
            throw GitHubAPIError.http(http.statusCode, errorMessage(from: data))
        }
        if allowEmpty && data.isEmpty { return Data() }
        return data
    }

    private var pathSegmentAllowed: CharacterSet {
        .alphanumerics.union(CharacterSet(charactersIn: "-._~"))
    }

    private var queryValueAllowed: CharacterSet {
        .alphanumerics.union(CharacterSet(charactersIn: "-._~"))
    }

    private func encodedPath(_ path: String) -> String {
        path.split(separator: "/", omittingEmptySubsequences: false)
            .map { String($0).addingPercentEncoding(withAllowedCharacters: pathSegmentAllowed) ?? String($0) }
            .joined(separator: "/")
    }

    private func encodedRef(_ ref: String) -> String {
        ref.split(separator: "/", omittingEmptySubsequences: false)
            .map { String($0).addingPercentEncoding(withAllowedCharacters: pathSegmentAllowed) ?? String($0) }
            .joined(separator: "/")
    }

    private func queryEncoded(_ value: String) -> String {
        value.addingPercentEncoding(withAllowedCharacters: queryValueAllowed) ?? value
    }

    // MARK: - Repositories

    func repositories() async throws -> [GitHubRepository] {
        let data = try await perform(request("/user/repos?per_page=100&sort=updated&affiliation=owner,collaborator,organization_member"))
        return try decoder.decode([GitHubRepository].self, from: data)
    }

    func createRepository(name: String, description: String, isPrivate: Bool) async throws -> GitHubRepository {
        let clean = name.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !clean.isEmpty else { throw GitHubAPIError.invalidFileName }
        let payload: [String: Any] = [
            "name": clean,
            "description": description.trimmingCharacters(in: .whitespacesAndNewlines),
            "private": isPrivate,
            "auto_init": true
        ]
        let body = try JSONSerialization.data(withJSONObject: payload)
        let data = try await perform(request("/user/repos", method: "POST", body: body))
        return try decoder.decode(GitHubRepository.self, from: data)
    }

    func renameRepository(owner: String, repo: String, newName: String) async throws -> GitHubRepository {
        let clean = newName.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !clean.isEmpty else { throw GitHubAPIError.invalidFileName }
        let body = try JSONSerialization.data(withJSONObject: ["name": clean])
        let data = try await perform(request("/repos/\(owner)/\(repo)", method: "PATCH", body: body))
        return try decoder.decode(GitHubRepository.self, from: data)
    }

    func deleteRepository(owner: String, repo: String) async throws {
        _ = try await perform(request("/repos/\(owner)/\(repo)", method: "DELETE"), allowEmpty: true)
    }

    // MARK: - Actions / branches

    func workflows(owner: String, repo: String) async throws -> [GitHubWorkflow] {
        let data = try await perform(request("/repos/\(owner)/\(repo)/actions/workflows?per_page=100"))
        return try decoder.decode(WorkflowListResponse.self, from: data).workflows
    }

    func branches(owner: String, repo: String) async throws -> [GitHubBranch] {
        let data = try await perform(request("/repos/\(owner)/\(repo)/branches?per_page=100"))
        return try decoder.decode([GitHubBranch].self, from: data)
    }

    func dispatch(owner: String, repo: String, workflowID: Int, ref: String, inputs: [String: String] = [:]) async throws {
        var payload: [String: Any] = ["ref": ref]
        if !inputs.isEmpty { payload["inputs"] = inputs }
        let body = try JSONSerialization.data(withJSONObject: payload)
        _ = try await perform(request("/repos/\(owner)/\(repo)/actions/workflows/\(workflowID)/dispatches", method: "POST", body: body), allowEmpty: true)
    }

    func runs(owner: String, repo: String, workflowID: Int, branch: String? = nil) async throws -> [GitHubRun] {
        var path = "/repos/\(owner)/\(repo)/actions/workflows/\(workflowID)/runs?per_page=20"
        if let branch { path += "&branch=\(queryEncoded(branch))" }
        let data = try await perform(request(path))
        return try decoder.decode(RunListResponse.self, from: data).workflow_runs
    }

    func artifacts(owner: String, repo: String, runID: Int) async throws -> [GitHubArtifact] {
        let data = try await perform(request("/repos/\(owner)/\(repo)/actions/runs/\(runID)/artifacts?per_page=100"))
        return try decoder.decode(ArtifactListResponse.self, from: data).artifacts
    }

    func cancel(owner: String, repo: String, runID: Int) async throws {
        _ = try await perform(request("/repos/\(owner)/\(repo)/actions/runs/\(runID)/cancel", method: "POST"), allowEmpty: true)
    }

    func ensureBranch(owner: String, repo: String, branch: String, baseBranch: String) async throws {
        let allBranches = try await branches(owner: owner, repo: repo)
        if allBranches.contains(where: { $0.name == branch }) { return }

        let baseData = try await perform(request("/repos/\(owner)/\(repo)/git/ref/heads/\(encodedRef(baseBranch))"))
        let base = try decoder.decode(GitHubReference.self, from: baseData)
        let payload: [String: Any] = ["ref": "refs/heads/\(branch)", "sha": base.object.sha]
        let body = try JSONSerialization.data(withJSONObject: payload)
        _ = try await perform(request("/repos/\(owner)/\(repo)/git/refs", method: "POST", body: body))
    }

    // MARK: - Repository files

    func contents(owner: String, repo: String, path: String, branch: String) async throws -> [GitHubContentItem] {
        let endpoint: String
        if path.isEmpty {
            endpoint = "/repos/\(owner)/\(repo)/contents?ref=\(queryEncoded(branch))"
        } else {
            endpoint = "/repos/\(owner)/\(repo)/contents/\(encodedPath(path))?ref=\(queryEncoded(branch))"
        }
        let data = try await perform(request(endpoint))
        let items = try decoder.decode([GitHubContentItem].self, from: data)
        return items.sorted {
            if $0.isDirectory != $1.isDirectory { return $0.isDirectory && !$1.isDirectory }
            return $0.name.localizedCaseInsensitiveCompare($1.name) == .orderedAscending
        }
    }

    func contentMetadata(owner: String, repo: String, path: String, branch: String) async throws -> GitHubContentMetadata? {
        let p = encodedPath(path)
        let (data, http) = try await response(request("/repos/\(owner)/\(repo)/contents/\(p)?ref=\(queryEncoded(branch))"))
        if http.statusCode == 404 { return nil }
        guard (200..<300).contains(http.statusCode) else {
            throw GitHubAPIError.http(http.statusCode, errorMessage(from: data))
        }
        return try decoder.decode(GitHubContentMetadata.self, from: data)
    }

    func fileInfo(owner: String, repo: String, path: String, branch: String) async throws -> GitHubFileContent {
        let data = try await perform(request("/repos/\(owner)/\(repo)/contents/\(encodedPath(path))?ref=\(queryEncoded(branch))"))
        return try decoder.decode(GitHubFileContent.self, from: data)
    }

    func rawFileData(owner: String, repo: String, path: String, branch: String) async throws -> Data {
        let req = try request(
            "/repos/\(owner)/\(repo)/contents/\(encodedPath(path))?ref=\(queryEncoded(branch))",
            accept: "application/vnd.github.raw+json"
        )
        return try await perform(req)
    }

    func uploadFile(owner: String, repo: String, path: String, data: Data, branch: String, message: String) async throws -> UploadedRepositoryFile {
        guard data.count <= 90 * 1024 * 1024 else { throw GitHubAPIError.fileTooLarge(Int64(data.count)) }
        let clean = path.trimmingCharacters(in: CharacterSet(charactersIn: "/").union(.whitespacesAndNewlines))
        guard !clean.isEmpty else { throw GitHubAPIError.invalidFileName }

        let existing = try await contentMetadata(owner: owner, repo: repo, path: clean, branch: branch)
        var payload: [String: Any] = [
            "message": message,
            "content": data.base64EncodedString(),
            "branch": branch
        ]
        if let existing { payload["sha"] = existing.sha }
        let body = try JSONSerialization.data(withJSONObject: payload)
        let req = try request("/repos/\(owner)/\(repo)/contents/\(encodedPath(clean))", method: "PUT", body: body)
        let (responseData, http) = try await response(req)
        guard (200..<300).contains(http.statusCode) else {
            let message = errorMessage(from: responseData)
            if http.statusCode == 403 {
                let needsWorkflows = clean.hasPrefix(".github/workflows/")
                let hint = needsWorkflows
                    ? "Token needs Contents: Read and write AND Workflows: Read and write for this path."
                    : "Token needs Contents: Read and write for this repository. Also make sure this repository is included in the token's Repository access."
                throw GitHubAPIError.http(http.statusCode, "\(message) \(hint)")
            }
            throw GitHubAPIError.http(http.statusCode, message)
        }
        return UploadedRepositoryFile(path: clean, branch: branch)
    }

    func createTextFile(owner: String, repo: String, path: String, text: String, branch: String) async throws {
        guard let data = text.data(using: .utf8) else { throw GitHubAPIError.invalidTextFile }
        _ = try await uploadFile(owner: owner, repo: repo, path: path, data: data, branch: branch, message: "Create \(path) from IPA Action")
    }

    func createFolder(owner: String, repo: String, path: String, branch: String) async throws {
        let clean = path.trimmingCharacters(in: CharacterSet(charactersIn: "/").union(.whitespacesAndNewlines))
        guard !clean.isEmpty else { throw GitHubAPIError.invalidFileName }
        _ = try await uploadFile(
            owner: owner,
            repo: repo,
            path: "\(clean)/.gitkeep",
            data: Data(),
            branch: branch,
            message: "Create folder \(clean) from IPA Action"
        )
    }

    func deleteFile(owner: String, repo: String, path: String, sha: String, branch: String, message: String? = nil) async throws {
        let payload: [String: Any] = [
            "message": message ?? "Delete \(path) from IPA Action",
            "sha": sha,
            "branch": branch
        ]
        let body = try JSONSerialization.data(withJSONObject: payload)
        _ = try await perform(request("/repos/\(owner)/\(repo)/contents/\(encodedPath(path))", method: "DELETE", body: body), allowEmpty: true)
    }

    private func collectFiles(owner: String, repo: String, path: String, branch: String) async throws -> [GitHubContentItem] {
        var files: [GitHubContentItem] = []
        let children = try await contents(owner: owner, repo: repo, path: path, branch: branch)
        for child in children {
            if child.isDirectory {
                files.append(contentsOf: try await collectFiles(owner: owner, repo: repo, path: child.path, branch: branch))
            } else {
                files.append(child)
            }
        }
        return files
    }

    func deleteDirectory(owner: String, repo: String, path: String, branch: String) async throws {
        let files = try await collectFiles(owner: owner, repo: repo, path: path, branch: branch)
        for file in files.reversed() {
            try await deleteFile(owner: owner, repo: repo, path: file.path, sha: file.sha, branch: branch, message: "Delete \(path) from IPA Action")
        }
    }

    func moveFile(owner: String, repo: String, source: GitHubContentItem, destinationPath: String, branch: String) async throws {
        let clean = destinationPath.trimmingCharacters(in: CharacterSet(charactersIn: "/").union(.whitespacesAndNewlines))
        guard !clean.isEmpty else { throw GitHubAPIError.invalidFileName }
        guard clean != source.path else { throw GitHubAPIError.invalidMove }
        let data = try await rawFileData(owner: owner, repo: repo, path: source.path, branch: branch)
        _ = try await uploadFile(owner: owner, repo: repo, path: clean, data: data, branch: branch, message: "Move \(source.path) to \(clean)")
        try await deleteFile(owner: owner, repo: repo, path: source.path, sha: source.sha, branch: branch, message: "Move \(source.path) to \(clean)")
    }

    func moveDirectory(owner: String, repo: String, sourcePath: String, destinationPath: String, branch: String) async throws {
        let sourceClean = sourcePath.trimmingCharacters(in: CharacterSet(charactersIn: "/").union(.whitespacesAndNewlines))
        let destClean = destinationPath.trimmingCharacters(in: CharacterSet(charactersIn: "/").union(.whitespacesAndNewlines))
        guard !sourceClean.isEmpty, !destClean.isEmpty else { throw GitHubAPIError.invalidFileName }
        guard sourceClean != destClean, !destClean.hasPrefix(sourceClean + "/") else { throw GitHubAPIError.invalidMove }

        let files = try await collectFiles(owner: owner, repo: repo, path: sourceClean, branch: branch)
        for file in files {
            let suffix = String(file.path.dropFirst(sourceClean.count)).trimmingCharacters(in: CharacterSet(charactersIn: "/"))
            let newPath = suffix.isEmpty ? destClean : "\(destClean)/\(suffix)"
            let data = try await rawFileData(owner: owner, repo: repo, path: file.path, branch: branch)
            _ = try await uploadFile(owner: owner, repo: repo, path: newPath, data: data, branch: branch, message: "Move folder \(sourceClean) to \(destClean)")
        }
        for file in files.reversed() {
            try await deleteFile(owner: owner, repo: repo, path: file.path, sha: file.sha, branch: branch, message: "Move folder \(sourceClean) to \(destClean)")
        }
    }

    // MARK: - IPA artifacts

    func downloadIPA(owner: String, repo: String, artifact: GitHubArtifact) async throws -> URL {
        let req = try request("/repos/\(owner)/\(repo)/actions/artifacts/\(artifact.id)/zip")
        let (zipURL, response) = try await session.download(for: req)
        guard let http = response as? HTTPURLResponse, (200..<300).contains(http.statusCode) else {
            throw GitHubAPIError.invalidResponse
        }

        let fm = FileManager.default
        let tempRoot = fm.temporaryDirectory.appendingPathComponent("IPAAction-\(UUID().uuidString)", isDirectory: true)
        try fm.createDirectory(at: tempRoot, withIntermediateDirectories: true)
        let archiveURL = tempRoot.appendingPathComponent("artifact.zip")
        try fm.moveItem(at: zipURL, to: archiveURL)
        let extractURL = tempRoot.appendingPathComponent("unzipped", isDirectory: true)
        try fm.createDirectory(at: extractURL, withIntermediateDirectories: true)
        try fm.unzipItem(at: archiveURL, to: extractURL)

        let enumerator = fm.enumerator(at: extractURL, includingPropertiesForKeys: nil)
        while let url = enumerator?.nextObject() as? URL {
            if url.pathExtension.lowercased() == "ipa" {
                let target = fm.temporaryDirectory.appendingPathComponent("\(artifact.name)-\(artifact.id).ipa")
                try? fm.removeItem(at: target)
                try fm.copyItem(at: url, to: target)
                return target
            }
        }
        throw GitHubAPIError.ipaNotFound
    }
}
