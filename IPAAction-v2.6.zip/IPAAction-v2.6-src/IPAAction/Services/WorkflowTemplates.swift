import Foundation

enum WorkflowTemplates {
    static func sanitizedFileName(_ original: String, fallback: String = "Project.zip") -> String {
        let allowed = CharacterSet.alphanumerics.union(CharacterSet(charactersIn: "._-"))
        let cleaned = original.unicodeScalars.map { allowed.contains($0) ? Character(String($0)) : Character("_") }
        let result = String(cleaned).trimmingCharacters(in: CharacterSet(charactersIn: "."))
        return result.isEmpty ? fallback : result
    }

    static func sanitizedBranch(_ original: String) -> String {
        let allowed = CharacterSet.alphanumerics.union(CharacterSet(charactersIn: "-_/"))
        let cleaned = original.unicodeScalars.map { allowed.contains($0) ? Character(String($0)) : Character("-") }
        return String(cleaned).trimmingCharacters(in: CharacterSet(charactersIn: "/-"))
    }

    static func universalIPA(archivePath: String, branch: String, workflowPath: String) -> String {
        let safeArchive = archivePath.replacingOccurrences(of: "\"", with: "")
        let safeBranch = branch.replacingOccurrences(of: "\"", with: "")
        let safeWorkflow = workflowPath.replacingOccurrences(of: "\"", with: "")

        return """
        name: Build iOS IPA

        on:
          workflow_dispatch:
          push:
            branches:
              - "\(safeBranch)"
            paths:
              - "\(safeArchive)"

        permissions:
          contents: read

        jobs:
          build:
            name: Build IPA
            runs-on: macos-15

            steps:
              - name: Checkout
                uses: actions/checkout@v4

              - name: Verify project archive
                shell: bash
                run: |
                  set -euo pipefail
                  test -s "\(safeArchive)"
                  unzip -t "\(safeArchive)" >/dev/null
                  echo "Archive OK: \(safeArchive)"

              - name: Extract project
                shell: bash
                run: |
                  set -euo pipefail
                  rm -rf "$RUNNER_TEMP/ipaaction-source"
                  mkdir -p "$RUNNER_TEMP/ipaaction-source"
                  unzip -q "\(safeArchive)" -d "$RUNNER_TEMP/ipaaction-source"
                  echo "SOURCE_ROOT=$RUNNER_TEMP/ipaaction-source" >> "$GITHUB_ENV"

              - name: Generate Xcode project when needed
                shell: bash
                run: |
                  set -euo pipefail
                  if ! find "$SOURCE_ROOT" -type d \\( -name '*.xcworkspace' -o -name '*.xcodeproj' \\) -print -quit | grep -q .; then
                    PROJECT_YML="$(find "$SOURCE_ROOT" -type f -name project.yml -print -quit)"
                    if [ -n "$PROJECT_YML" ]; then
                      brew install xcodegen
                      cd "$(dirname "$PROJECT_YML")"
                      xcodegen generate
                    fi
                  fi

              - name: Detect Xcode container and scheme
                id: detect
                shell: bash
                run: |
                  set -euo pipefail

                  WORKSPACE="$(find "$SOURCE_ROOT" -type d -name '*.xcworkspace' ! -path '*/Pods/*' -print -quit)"
                  PROJECT="$(find "$SOURCE_ROOT" -type d -name '*.xcodeproj' ! -path '*/Pods/*' -print -quit)"

                  if [ -n "$WORKSPACE" ]; then
                    KIND="workspace"
                    CONTAINER="$WORKSPACE"
                    xcodebuild -list -json -workspace "$CONTAINER" > "$RUNNER_TEMP/xcode-list.json"
                  elif [ -n "$PROJECT" ]; then
                    KIND="project"
                    CONTAINER="$PROJECT"
                    xcodebuild -list -json -project "$CONTAINER" > "$RUNNER_TEMP/xcode-list.json"
                  else
                    echo "ERROR: no .xcworkspace or .xcodeproj found"
                    exit 1
                  fi

                  SCHEME="$(python3 -c 'import json, os; p=os.path.join(os.environ["RUNNER_TEMP"], "xcode-list.json"); d=json.load(open(p, "r", encoding="utf-8")); schemes=sum([v.get("schemes", []) for v in d.values() if isinstance(v, dict)], []); assert schemes, "No shared/buildable Xcode scheme found"; print(schemes[0])')"

                  echo "kind=$KIND" >> "$GITHUB_OUTPUT"
                  echo "container=$CONTAINER" >> "$GITHUB_OUTPUT"
                  echo "scheme=$SCHEME" >> "$GITHUB_OUTPUT"
                  echo "Using $KIND: $CONTAINER"
                  echo "Scheme: $SCHEME"

              - name: Resolve Swift packages
                shell: bash
                run: |
                  set -euo pipefail
                  if [ "${{ steps.detect.outputs.kind }}" = "workspace" ]; then
                    xcodebuild -resolvePackageDependencies \
                      -workspace "${{ steps.detect.outputs.container }}" \
                      -scheme "${{ steps.detect.outputs.scheme }}"
                  else
                    xcodebuild -resolvePackageDependencies \
                      -project "${{ steps.detect.outputs.container }}" \
                      -scheme "${{ steps.detect.outputs.scheme }}"
                  fi

              - name: Build unsigned iPhone app
                shell: bash
                run: |
                  set -euo pipefail
                  COMMON=(
                    -scheme "${{ steps.detect.outputs.scheme }}"
                    -configuration Release
                    -sdk iphoneos
                    -derivedDataPath "$RUNNER_TEMP/ipaaction-derived"
                    CODE_SIGNING_ALLOWED=NO
                    CODE_SIGNING_REQUIRED=NO
                    CODE_SIGN_IDENTITY=""
                    DEVELOPMENT_TEAM=""
                    clean build
                  )

                  if [ "${{ steps.detect.outputs.kind }}" = "workspace" ]; then
                    xcodebuild -workspace "${{ steps.detect.outputs.container }}" "${COMMON[@]}"
                  else
                    xcodebuild -project "${{ steps.detect.outputs.container }}" "${COMMON[@]}"
                  fi

              - name: Package IPA
                shell: bash
                run: |
                  set -euo pipefail
                  APP_PATH="$(find "$RUNNER_TEMP/ipaaction-derived/Build/Products" -type d -path '*Release-iphoneos*' -name '*.app' -print -quit)"
                  if [ -z "$APP_PATH" ]; then
                    echo "ERROR: built .app not found"
                    exit 1
                  fi

                  rm -rf "$RUNNER_TEMP/Payload" "$RUNNER_TEMP/App.ipa"
                  mkdir -p "$RUNNER_TEMP/Payload"
                  cp -R "$APP_PATH" "$RUNNER_TEMP/Payload/"
                  cd "$RUNNER_TEMP"
                  /usr/bin/zip -qry App.ipa Payload
                  unzip -t App.ipa >/dev/null
                  ls -lh App.ipa

              - name: Upload IPA
                uses: actions/upload-artifact@v4
                with:
                  name: iOS-IPA
                  path: ${{ runner.temp }}/App.ipa
                  if-no-files-found: error
                  retention-days: 14
        """
    }
}
