import Foundation

enum SideloaderError: LocalizedError {
    case invalidURL
    case badResponse(Int, String)

    var errorDescription: String? {
        switch self {
        case .invalidURL: return "Invalid sideloader URL."
        case let .badResponse(code, message): return "Sideloader error \(code): \(message)"
        }
    }
}

struct SideloaderClient {
    /// Expected API: POST {baseURL}/api/install, multipart form-data with field name `ipa`.
    /// Optional header: Authorization: Bearer {apiKey}
    func install(ipaURL: URL, baseURL: String, apiKey: String?) async throws -> String {
        let trimmed = baseURL.trimmingCharacters(in: .whitespacesAndNewlines).trimmingCharacters(in: CharacterSet(charactersIn: "/"))
        guard let url = URL(string: trimmed + "/api/install") else { throw SideloaderError.invalidURL }

        let boundary = "IPAAction-\(UUID().uuidString)"
        var request = URLRequest(url: url)
        request.httpMethod = "POST"
        request.setValue("multipart/form-data; boundary=\(boundary)", forHTTPHeaderField: "Content-Type")
        if let apiKey, !apiKey.isEmpty { request.setValue("Bearer \(apiKey)", forHTTPHeaderField: "Authorization") }

        var body = Data()
        body.append("--\(boundary)\r\n".data(using: .utf8)!)
        body.append("Content-Disposition: form-data; name=\"ipa\"; filename=\"\(ipaURL.lastPathComponent)\"\r\n".data(using: .utf8)!)
        body.append("Content-Type: application/octet-stream\r\n\r\n".data(using: .utf8)!)
        body.append(try Data(contentsOf: ipaURL))
        body.append("\r\n--\(boundary)--\r\n".data(using: .utf8)!)
        request.httpBody = body

        let (data, response) = try await URLSession.shared.data(for: request)
        guard let http = response as? HTTPURLResponse else { throw SideloaderError.badResponse(-1, "Invalid response") }
        let text = String(data: data, encoding: .utf8) ?? ""
        guard (200..<300).contains(http.statusCode) else { throw SideloaderError.badResponse(http.statusCode, text) }
        return text.isEmpty ? "Install request accepted." : text
    }
}
